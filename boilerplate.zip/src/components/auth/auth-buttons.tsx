"use client";

import { signIn, signOut } from "next-auth/react";
import {Button} from "@/components/ui/button"
import {Power, PowerOff} from "lucide-react"

    import { fromJSONSchema } from "zod";


export function SignInButton() {
    return (
        <Button variant="ghost" onClick={() => signIn()}><Power />Sign in</Button>
    );
}

export function SignOutButton() {
    return (
        <Button variant="ghost"  onClick={() => signOut()}><PowerOff />Sign Out</Button>
    );
}