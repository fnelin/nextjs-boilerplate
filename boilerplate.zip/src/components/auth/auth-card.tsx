import { auth } from "@/server/auth";
import Image from "next/image";
import { SignInButton, SignOutButton } from "./auth-buttons";
import {Card, CardHeader, CardTitle, CardContent} from "@/components/ui/card";

export default async function AuthCard() {
    let session = null;
    const imgSize = 32;
    try {
        session = await auth();
    } catch (error) {
        console.error("Auth error:", error);
        // Return just the sign in button if auth fails
        return (
            <section className="auth-status grid items-center gap-2 justify-center">
                <SignInButton />
            </section>
        );
    }

    return (
        <Card size="sm">
            <CardHeader>
                <CardTitle>
                    {session?.user ? (
                        <div className="flex items-center gap-2">
                            {session.user.image && (
                                <Image 
                                    src={session.user.image} 
                                    alt="" 
                                    width={imgSize} 
                                    height={imgSize} 
                                    className="rounded-full" 
                                />
                            )}
                            {session.user.name}
                            
                        </div>
                    ) : (
                        <div className="flex items-center gap-2 justify-center">
                            Guest
                        </div>
                    )}
                </CardTitle>
            </CardHeader>
            <CardContent>
                {session ? <SignOutButton /> : <SignInButton />}
            </CardContent>
        </Card>
    );
}