import AuthCard from "@/components/auth/auth-card"
import Link from "next/link"
import { Button } from "../ui/button"

export default function Sidebar(){

    return(
        <aside className="bg-blue-100 flex flex-col justify-between">
            <nav>
              <ul>
                <li><Button variant="link"><Link href="/">Hem</Link></Button></li>
                <li><Button variant="link"><Link href="/sidor/assignments">Uppgifter</Link></Button>
                <ul className="pl-2">
                  <li><Button variant="link"><Link href="/sidor/assignments/create">Skapa uppgift</Link></Button></li>
                </ul>
                </li>
                <li><Button variant="link"><Link href="/sidor/aichat">AI-Chat</Link></Button></li>
              </ul>
            </nav>
            <AuthCard />
        </aside>
    )
};