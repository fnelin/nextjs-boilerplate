import AuthCard from "@/components/auth/auth-card"
import Link from "next/link"
import { Button } from "../ui/button"

export default function Sidebar(){

    return(
        <aside className="bg-blue-100 flex flex-col justify-between">
            <nav>
              <ul>
                <li><Button variant="link"><Link href="/">Home</Link></Button></li>
                <li><Button variant="link"><Link href="/sidor/assignments">Assignments</Link></Button></li>
                <li><Button variant="link"><Link href="/sidor/aichat">Chat</Link></Button></li>
              </ul>
            </nav>
            <AuthCard />
        </aside>
    )
};