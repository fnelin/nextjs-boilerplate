import AuthCard from "@/components/auth/auth-card"

export default function Sidebar(){

    return(
        <aside className="bg-blue-100 flex flex-col justify-between">
            <nav>Sidebar</nav>
            <AuthCard />
        </aside>
    )
};