export default function Footer(){

    return(
        <footer className="bg-lime-100">
            Footer
        </footer>
    )
};