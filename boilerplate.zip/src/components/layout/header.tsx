export default function Header(){

    return(
        <header className="bg-amber-100">
            Header
        </header>
    )
};