"use client";
import { useSession } from "next-auth/react";
import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { trpc } from "@/trpc/client";
import { z } from "zod";
import { format } from "date-fns";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils/cn";
import { CalendarIcon, Plus, Trash2 } from "lucide-react";

const assignmentSchema = z.object({
  title: z.string().min(1, "Title is required").max(200),
  description: z.string().optional(),
  course: z.string().optional(),
  dueDate: z.date().optional(),
  status: z.enum(["DRAFT", "OPEN", "CLOSED", "ARCHIVED"]),
  objectives: z.array(z.object({
    description: z.string().min(1, "Objective description is required"),
    maxScore: z.number().positive("Max score must be positive")
  })).min(1, "At least one objective is required")
});

type AssignmentFormData = z.infer<typeof assignmentSchema>;

export function CreateAssignmentForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { register, control, handleSubmit, formState: { errors }, reset, setValue, watch } = useForm<AssignmentFormData>({
    resolver: zodResolver(assignmentSchema),
    defaultValues: {
      title: "",
      description: "",
      course: "",
      dueDate: undefined,
      status: "DRAFT",
      objectives: [{ description: "", maxScore: 100 }]
    }
  });
  
  const { fields, append, remove } = useFieldArray({
    control,
    name: "objectives"
  });
  
  const dueDate = watch("dueDate");
  
  const createAssignment = trpc.db.createAssignment.useMutation({
    onSuccess: () => {
      toast.success("Assignment created successfully");
      reset();
      setValue("objectives", [{ description: "", maxScore: 100 }]);
      setIsSubmitting(false);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create assignment");
      setIsSubmitting(false);
    }
  });
  
  const onSubmit = (data: AssignmentFormData) => {
    setIsSubmitting(true);
    createAssignment.mutate(data);
  };

  const addObjective = () => {
    if (fields.length < 10) {
      append({ description: "", maxScore: 100 });
    } else {
      toast.error("Maximum 10 objectives per assignment");
    }
  };

  const {data: session} = useSession();

return (

  <form onSubmit={handleSubmit(onSubmit)} className="max-w-3xl mx-auto space-y-8">
    {/* Assignment Information Section */}
    <div className="space-y-6 max-w-2/3">
      <h2 className="text-2xl font-semibold">Assignment Information</h2>
      
      <div className="max-w-3xl space-y-6">
        {/* Title */}
        <div className="space-y-2">
          <Label htmlFor="title">Title *</Label>
          <Input
            id="title"
            placeholder="e.g., Midterm Essay"
            {...register("title")}
            className={errors.title ? "border-red-500" : ""}
          />
          {errors.title && (
            <p className="text-sm text-red-500">{errors.title.message}</p>
          )}
        </div>

        {/* Description */}
        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            placeholder="Provide instructions for students..."
            className="min-h-25"
            {...register("description")}
          />
        </div>

        {/* Course and Due Date Row */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="course">Course</Label>
            <Input
              id="course"
              placeholder="e.g., English 101"
              {...register("course")}
            />
          </div>

          <div className="space-y-2">
            <Label>Due Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !dueDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dueDate ? format(dueDate, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dueDate}
                  onSelect={(date) => setValue("dueDate", date)}
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </div>
    </div>

    {/* Objectives Section */}
    <div className="space-y-4 max-w-2/3">
      <div className="flex justify-between items-center flex-wrap">
        <h2 className="text-2xl font-semibold">Objectives</h2>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={addObjective}
          disabled={fields.length >= 10}
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Objective ({fields.length}/10)
        </Button>
      </div>

      {errors.objectives && (
        <p className="text-sm text-red-500">{errors.objectives.message}</p>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 ">
        {fields.map((field, index) => (
          <Card key={field.id}>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1 space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label htmlFor={`objectives.${index}.description`}>
                          Objective {index + 1}*
                        </Label>
                        {fields.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => remove(index)}
                          className="text-red-500 hover:text-red-700 shrink-0"
                          >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                        )}
                      </div>
                      <Textarea
                        id={`objectives.${index}.description`}
                        placeholder="e.g., Student can analyze the main themes..."
                        {...register(`objectives.${index}.description`)}
                        className={cn(
                          "min-h-20",
                          errors.objectives?.[index]?.description ? "border-red-500" : ""
                        )}
                      />
                      {errors.objectives?.[index]?.description && (
                        <p className="text-sm text-red-500">
                          {errors.objectives[index]?.description?.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`objectives.${index}.maxScore`}>
                        Max Score *
                      </Label>
                      <Input
                        id={`objectives.${index}.maxScore`}
                        type="number"
                        step="0.5"
                        {...register(`objectives.${index}.maxScore`, {
                          valueAsNumber: true
                        })}
                        className={errors.objectives?.[index]?.maxScore ? "border-red-500" : ""}
                      />
                      {errors.objectives?.[index]?.maxScore && (
                        <p className="text-sm text-red-500">
                          {errors.objectives[index]?.maxScore?.message}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>

    {/* Submit Buttons */}
    <div className="flex gap-4 pt-4 w-2/3">
      <Button 
        type="submit" 
        disabled={isSubmitting || !session}
        className="flex-1"
      >
        {isSubmitting ? "Creating..." : "Create Assignment"}
      </Button>
      <Button 
        type="button" 
        variant="outline" 
        onClick={() => reset()}
      >
        Reset
      </Button>
    </div>
  </form>
);
}