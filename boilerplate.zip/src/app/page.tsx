import ChatInterface from "@/components/ai/chatinterface"
import { auth } from "@/server/auth"

export default async function Home() {
const session = await auth()

  return (
    <section>
      <h1>Page</h1>
      Welcome {session?.user?.name && `${session.user.name}` }
      <ChatInterface />
    </section>


  )
};