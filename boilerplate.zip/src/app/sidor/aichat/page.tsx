import ChatInterface from "@/components/ai/chatinterface";

export default function Chat() {
  return (
    <section>
      <ChatInterface />
    </section>
  )
}