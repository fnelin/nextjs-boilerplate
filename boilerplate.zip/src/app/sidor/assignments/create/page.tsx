import { CreateAssignmentForm } from "@/components/assignments/assignmentform"

export default function Assignements() {
  return (
    <section className="p-4">
      <CreateAssignmentForm />
    </section>
  )
}