"use client";

import { useSession } from "next-auth/react";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { trpc } from "@/trpc/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Edit, Trash2 } from "lucide-react";

export default function AssignmentDetails() {
  const { data: session } = useSession();
  const params = useParams();
  const assignmentId = params.id as string;
  const [assignment, setAssignment] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const getOneAssignment = trpc.db.getOneAssignment.useQuery(
    { id: assignmentId },
    {
      enabled: !!assignmentId,
    }
  );

  useEffect(() => {
    if (getOneAssignment.data) {
      setAssignment(getOneAssignment.data);
      setLoading(false);
    } else if (getOneAssignment.isError) {
      setLoading(false);
    }
  }, [getOneAssignment.data, getOneAssignment.isError]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "DRAFT":
        return "bg-gray-100 text-gray-800";
      case "OPEN":
        return "bg-green-100 text-green-800";
      case "CLOSED":
        return "bg-red-100 text-red-800";
      case "ARCHIVED":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Laddar uppgift...</div>
      </div>
    );
  }

  if (!assignment) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Uppgift hittades inte</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Uppgiftsdetaljer</h1>
        <div className="flex gap-2">
          <Button 
            variant="ghost"
            onClick={() => console.log("Edit assignment:", assignment.id)}
          >
            <Edit className="h-4 w-4 mr-2" />
            Redigera
          </Button>
          <Button 
            variant="ghost"
            onClick={() => console.log("Delete assignment:", assignment.id)}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Ta bort
          </Button>
        </div>
      </div>

      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-2xl">{assignment.title}</CardTitle>
            <Badge className={getStatusColor(assignment.status)}>
              {assignment.status}
            </Badge>
          </div>
          {assignment.course && (
            <div className="text-sm text-gray-600">Kurs: {assignment.course}</div>
          )}
        </CardHeader>
        <CardContent>
          {assignment.description && (
            <p className="text-gray-700 mb-6">{assignment.description}</p>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Calendar className="h-4 w-4" />
              <span>
                Sista dag: {assignment.dueDate ? new Date(assignment.dueDate).toLocaleDateString('sv-SE') : "Satt"}
              </span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Clock className="h-4 w-4" />
              <span>Skapad: {new Date(assignment.createdAt).toLocaleDateString('sv-SE')}</span>
            </div>
          </div>

          <div className="border-t pt-6">
            <h4 className="font-semibold text-lg mb-4">Krav ({assignment.objectives.length})</h4>
            <div className="space-y-3">
              {assignment.objectives.map((objective: any, index: number) => (
                <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="text-base">{objective.description}</span>
                  <span className="text-sm font-medium text-blue-600">
                    Max {objective.maxScore} poäng
                  </span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}