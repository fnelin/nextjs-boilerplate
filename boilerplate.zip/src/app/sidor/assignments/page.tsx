"use client";

import { useEffect, useState } from "react";
import { trpc } from "@/trpc/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Eye, Trash2 } from "lucide-react";

export default function listAssignments() {
  const [assignments, setAssignments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const getMyAssignments = trpc.db.getMyAssignments.useQuery();

  useEffect(() => {
    if (getMyAssignments.data) {
      setAssignments(getMyAssignments.data);
      setLoading(false);
    }
  }, [getMyAssignments.data]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "DRAFT":
        return "bg-gray-100 text-gray-800";
      case "OPEN":
        return "bg-green-100 text-green-800";
      case "CLOSED":
        return "bg-red-100 text-red-800";
      case "ARCHIVED":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Laddar uppgifter...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Lista uppgifter</h1>
        <Button 
          onClick={() => window.location.href = "/sidor/assignments/create"}
          variant="ghost"
        >
          Skapa ny uppgift
        </Button>
      </div>

      {assignments.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-lg text-gray-600 mb-4">Inga uppgifter hittades</div>
          <Button 
            variant="outline" 
            onClick={() => window.location.href = "/sidor/assignments/create"}
          >
            Skapa din första uppgift
          </Button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse border border-gray-300">
            <thead>
              <tr className="bg-gray-50">
                <th className="border border-gray-300 px-4 py-3 text-center font-semibold center">Namn</th>
                <th className="border border-gray-300 px-4 py-3 text-center font-semibold">Kurs</th>
                <th className="border border-gray-300 px-4 py-3 text-center font-semibold">Skapad</th>
                <th className="border border-gray-300 px-4 py-3 text-center font-semibold"># Krav</th>
                <th className="border border-gray-300 px-4 py-3 text-center font-semibold">Status</th>
                <th className="border border-gray-300 px-4 py-3 text-center font-semibold">Action</th>
              </tr>
            </thead>
            <tbody>
              {assignments.map((assignment) => (
                <tr key={assignment.id} className="hover:bg-gray-50">
                  <td className="border border-gray-300 px-4 py-3 font-medium">{assignment.title}</td>
                  <td className="border border-gray-300 px-4 py-3">{assignment.course || "-"}</td>
                  <td className="border border-gray-300 px-4 py-3 text-right">
                    {new Date(assignment.createdAt).toLocaleDateString('sv-SE')}
                  </td>
                  <td className="border border-gray-300 px-4 py-3 text-right">{assignment.objectives.length}</td>
                  <td className="border border-gray-300 px-4 py-3 text-center">
                    <Badge className={getStatusColor(assignment.status)}>
                      {assignment.status}
                    </Badge>
                  </td>
                  <td className="border border-gray-300 px-4 py-3">
                    <div className="flex gap-2 justify-around">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => window.location.href = `/sidor/assignments/${assignment.id}`}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => console.log("Edit assignment:", assignment.id)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => console.log("Delete assignment:", assignment.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}