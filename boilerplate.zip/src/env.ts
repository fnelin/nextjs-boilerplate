import { z } from "zod";

const envSchema = z.object({
  NEXTAUTH_URL: z.string().url(),
  NEXTAUTH_SECRET: z.string().min(1),
  GITHUB_ID: z.string().min(1),
  GITHUB_SECRET: z.string().min(1),
  DATABASE_URL: z.string().url(),
//       AI_BASE_URL: z.string().url().optional(),
//       AI_API_KEY: z.string().min(1),
//      AI_MODEL: z.string().min(1),
//       AI_ORG_ID: z.string().optional(),
  NODE_ENV: z
    .enum(["development", "test", "production"])
    .default("development"),
    });

export const env = envSchema.parse(process.env);