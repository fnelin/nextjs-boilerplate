export const GRADE_PROMPT = (input: {
  question: string;
  correctAnswer: string;
  userAnswer: string;
  rubric?: string;
}) => `
Grade the student's answer.

Question: ${input.question}
Correct Answer: ${input.correctAnswer}
Student Answer: ${input.userAnswer}
${input.rubric ? `Rubric: ${input.rubric}` : ''}

Return JSON:
{
  "grade": 0-100,
  "feedback": "feedback text",
  "strengths": ["strength1", "strength2"],
  "areasForImprovement": ["area1", "area2"],
  "isCorrect": boolean
}
`;