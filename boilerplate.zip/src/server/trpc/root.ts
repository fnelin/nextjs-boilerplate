import { aiRouter } from "@/server/trpc/routers/ai";
import { dbRouter } from "@/server/trpc/routers/db";
import { userRouter } from "@/server/trpc/routers/user";
import { createCallerFactory, createTRPCRouter } from "@/server/trpc/trpc";

/**
 * This is the primary router for your server.
 *
 * All routers added in /api/routers should be manually added here.
 */
export const appRouter = createTRPCRouter({
  ai: aiRouter,
  db: dbRouter,
  user: userRouter, 
});

// export type definition of API
export type AppRouter = typeof appRouter;

/**
 * Create a server-side caller for the tRPC API.
 * @example
 * const trpc = createCaller(createContext);
 * const res = await trpc.post.all();
 *       ^? Post[]
 */
export const createCaller = createCallerFactory(appRouter);
