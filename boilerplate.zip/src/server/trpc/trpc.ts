import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import { ZodError } from "zod";
import { UserRole } from "@prisma/client";

import { createTRPCContext } from "./context";

export { createTRPCContext };

const t = initTRPC.context<typeof createTRPCContext>().create({
  transformer: superjson,
  errorFormatter({ shape, error }) {
    return {
      ...shape,
      data: {
        ...shape.data,
        zodError:
          error.cause instanceof ZodError ? error.cause.flatten() : null,
      },
    };
  },
});

export const createCallerFactory = t.createCallerFactory;

export const createTRPCRouter = t.router;

const timingMiddleware = t.middleware(async ({ next, path }) => {
  const start = Date.now();

  if (t._config.isDev) {
    const waitMs = Math.floor(Math.random() * 400) + 100;
    await new Promise((resolve) => setTimeout(resolve, waitMs));
  }

  const result = await next();

  const end = Date.now();
  console.log(`[tRPC] ${path} took ${end - start}ms`);

  return result;
});

export const publicProcedure = t.procedure.use(timingMiddleware);

export const protectedProcedure = t.procedure
  .use(timingMiddleware)
  .use(({ ctx, next }) => {
    if (!ctx.session?.user) {
      throw new TRPCError({ code: "UNAUTHORIZED" });
    }
    return next({
      ctx: {
        session: { ...ctx.session, user: ctx.session.user },
      },
    });
  });

// export const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
//   if (ctx.session.user?.role !== UserRole.ADMIN) {
//     throw new TRPCError({
//       code: "FORBIDDEN",
//       message: "Admin access required",
//     });
//   }
//   return next();
// });

// Role middleware (using the protected procedure internally)
const roleProcedure = (allowedRoles: UserRole[]) => 
  protectedProcedure.use(async ({ ctx, next }) => {
    const user = await ctx.db.user.findUnique({
      where: { id: ctx.session.user.id },
      select: { role: true }
    });
    
    if (!user || !allowedRoles.includes(user.role)) {
      throw new TRPCError({ code: 'FORBIDDEN' });
    }
    
    return next({ ctx: { ...ctx, user: user } });
  });

// Pre-built role procedures for common cases
export const adminProcedure = roleProcedure([UserRole.ADMIN]);
export const teacherProcedure = roleProcedure([UserRole.TEACHER, UserRole.ADMIN]);