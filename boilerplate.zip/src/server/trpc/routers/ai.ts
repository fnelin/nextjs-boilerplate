import { createTRPCRouter, publicProcedure, protectedProcedure } from "@/server/trpc/trpc";
import { z } from "zod";
import { GRADE_PROMPT } from "@/server/ai/prompt";

const chat = publicProcedure
  .input(z.object({
    userMessage: z.string().min(1).max(1000),
  }))
  .mutation(async ({ ctx, input }) => {
    const response = await ctx.ai.call([
      { role: "system", content: "You are a helpful assistant." },
      { role: "user", content: input.userMessage }
    ]);

    return { success: true, message: response };
  });

 const gradeAnswer = protectedProcedure
  .input(z.object({
    question: z.string(),
    correctAnswer: z.string(),
    userAnswer: z.string(),
    rubric: z.string().optional(),
  }))
  .mutation(async ({ ctx, input }) => {
    const prompt = GRADE_PROMPT(input);
    const response = await ctx.ai.call([
      { role: "system", content: "You are a strict but fair teacher." },
      { role: "user", content: prompt }
    ], { temperature: 0.3 });

    try {
      const result = JSON.parse(response);
      return { success: true, ...result };
    } catch {
      return { success: false, error: "Failed to parse grade" };
    }
  });

  export const aiRouter = createTRPCRouter({
    getMessage: chat,
    gradeAnswer: gradeAnswer,
  });