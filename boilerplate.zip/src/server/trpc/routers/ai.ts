import { createTRPCRouter, publicProcedure, protectedProcedure } from "@/server/trpc/trpc";
import { z } from "zod";
import { GRADE_PROMPT } from "@/server/ai/prompt";
import { env } from "@/env";

const AI_CONFIG = {
  CHAT: {
    TEMPERATURE: 0.7,
    MAX_TOKENS: 500,
  },
  GRADING: {
    TEMPERATURE: 0.3,
    MAX_TOKENS: 300,
  },
};

const chat = publicProcedure
  .input(z.object({ userMessage: z.string().min(1).max(1000) }))
  .mutation(async ({ ctx, input }) => {
    const completion = await ctx.ai.chat.completions.create({
      model: env.AI_MODEL,
      messages: [
        { role: "system", content: "You are a helpful assistant." },
        { role: "user", content: input.userMessage }
      ],
      temperature: AI_CONFIG.CHAT.TEMPERATURE,
      max_tokens: AI_CONFIG.CHAT.MAX_TOKENS,
    });

    return {
      success: true,
      message: completion.choices[0]?.message?.content || "",
    };
  });

const gradeAnswer = protectedProcedure
  .input(z.object({
    question: z.string(),
    correctAnswer: z.string(),
    userAnswer: z.string(),
    rubric: z.string().optional(),
  }))
  .mutation(async ({ ctx, input }) => {
    const prompt = GRADE_PROMPT(input);
    
    const completion = await ctx.ai.chat.completions.create({
      model: env.AI_MODEL,
      messages: [
        { role: "system", content: "You are a strict but fair teacher. Return JSON only." },
        { role: "user", content: prompt }
      ],
      temperature: AI_CONFIG.GRADING.TEMPERATURE,
      max_tokens: AI_CONFIG.GRADING.MAX_TOKENS,
    });

    const response = completion.choices[0]?.message?.content || "";
    
    try {
      const result = JSON.parse(response);
      return { success: true, ...result };
    } catch {
      return { success: false, error: "Failed to parse grade" };
    }
  });

export const aiRouter = createTRPCRouter({
  getMessage: chat,
  gradeAnswer: gradeAnswer,
});