import { createTRPCRouter, protectedProcedure, publicProcedure, adminProcedure } from "@/server/trpc/trpc";

export const aiRouter = createTRPCRouter({


});