import { createTRPCRouter, protectedProcedure } from "@/server/trpc/trpc";
import { z } from "zod";
import { AssignmentStatus } from "@prisma/client";

const createAssignment = protectedProcedure
  .input(z.object({
    title: z.string().min(1).max(200),
    description: z.string().optional(),
    course: z.string().optional(),
    dueDate: z.date().optional(),
    status: z.nativeEnum(AssignmentStatus).default(AssignmentStatus.DRAFT),
    objectives: z.array(z.object({
      description: z.string().min(1),
      maxScore: z.number().positive()
    })).min(1)
  }))
  .mutation(async ({ ctx, input }) => {
    return ctx.db.assignment.create({
      data: {
        title: input.title,
        description: input.description,
        course: input.course,
        dueDate: input.dueDate,
        status: input.status,
        teacherId: ctx.session.user.id,
        objectives: {
          create: input.objectives
        }
      },
      include: { objectives: true }
    });
  });

const getMyAssignments = protectedProcedure
  .input(z.object({
    status: z.nativeEnum(AssignmentStatus).optional()
  }).optional())
  .query(async ({ ctx, input }) => {
    return ctx.db.assignment.findMany({
      where: {
        teacherId: ctx.session.user.id,
        ...(input?.status && { status: input.status })
      },
      include: { objectives: true },
      orderBy: { createdAt: 'desc' }
    });
  });

export const dbRouter = createTRPCRouter({
  createAssignment: createAssignment,
  getMyAssignments: getMyAssignments,
});