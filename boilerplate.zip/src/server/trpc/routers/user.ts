import { z } from "zod";
import { createTRPCRouter, protectedProcedure, publicProcedure, adminProcedure, teacherProcedure } from "@/server/trpc/trpc";
import { UserRole } from "@prisma/client";

export const userRouter = createTRPCRouter({
  // Get all users with their roles
  getAllUsers: protectedProcedure.query(async ({ ctx }) => {

    const users = await ctx.db.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        image: true,
        role: true,
      },
      orderBy: {
        name: "desc",
      },
    });
    
    return users;
  }),
  
  // Update a user's role
  updateUserRole: adminProcedure
    .input(
      z.object({
        userId: z.string(),
        role: z.nativeEnum(UserRole),
      })
    )
    .mutation(async ({ ctx, input }) => {
      
      const updatedUser = await ctx.db.user.update({
        where: { id: input.userId },
        data: { role: input.role },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
        },
      });
      
      return updatedUser;
    }),
    
  // Bulk update multiple users (optional, useful for batch operations)
  bulkUpdateRoles: adminProcedure
    .input(
      z.object({
        updates: z.array(
          z.object({
            userId: z.string(),
            role: z.nativeEnum(UserRole),
          })
        ),
      })
    )
    .mutation(async ({ ctx, input }) => {
      
      const updates = input.updates.map((update) =>
        ctx.db.user.update({
          where: { id: update.userId },
          data: { role: update.role },
        })
      );
      
      const results = await ctx.db.$transaction(updates);
      return results;
    }),
});