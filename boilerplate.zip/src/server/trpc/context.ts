import { auth } from "@/server/auth";
import db from "@/server/db";
import { ai } from "@/server/llm";

export const createTRPCContext = async (opts: { headers: Headers }) => {
  const session = await auth();
  return {
    db,
    ai,
    session,
    ...opts,
  };
};