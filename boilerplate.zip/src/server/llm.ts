// server/ai/client.ts
import { env } from "@/env";

// Singleton AI client
class AIClient {
  private baseURL: string;
  private model: string;

  constructor() {
    this.baseURL = env.AI_BASE_URL;
    this.model = env.AI_MODEL;
  }

  async call(messages: Array<{ role: string; content: string }>, options?: { temperature?: number }) {
    const response = await fetch(`${this.baseURL}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: this.model,
        messages,
        temperature: options?.temperature ?? 0.7,
        max_tokens: 500,
      }),
    });

    const data = await response.json();
    return data.choices[0]?.message?.content || "";
  }
}

// Export a single instance (pooled connection equivalent)
export const ai = new AIClient();