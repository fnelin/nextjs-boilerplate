import OpenAI from 'openai';
import { env } from "@/env";

export const ai = new OpenAI({
  baseURL: env.AI_BASE_URL,
  apiKey: env.AI_API_KEY,
    defaultHeaders: {
    "HTTP-Referer": "https://localhost:3000",
    "X-Title": "At home development",
    "X-Description": "At home testing development and connections.",
    "X-Version": "0.0.5"
  },
});