import { createCaller } from "@/server/trpc/root";
import { createContext } from "./context";

export const caller = createCaller(createContext);