import { cache } from "react";
import { headers } from "next/headers";
import { createTRPCContext } from "@/server/trpc/trpc";

export const createContext = cache(async () => {
  const heads = new Headers(await headers());
  heads.set("x-trpc-source", "rsc");

  return createTRPCContext({
    headers: heads,
  });
});