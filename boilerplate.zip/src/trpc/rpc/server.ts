import "server-only";

import { createHydrationHelpers } from "@trpc/react-query/rsc";
import { cache } from "react";

import { caller } from "./caller";
import { createQueryClient } from "./query-client";
import { type AppRouter } from "@/server/trpc/root";

const getQueryClient = cache(createQueryClient);

export const { trpc: api, HydrateClient } =
  createHydrationHelpers<AppRouter>(caller, getQueryClient);