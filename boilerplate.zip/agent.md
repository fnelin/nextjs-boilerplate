You are helping build a Next.js full-stack application. 
Follow the file structure and decisions in this document exactly. 
Do not suggest alternative libraries or patterns unless explicitly asked.

# Context Provider

## How to Use This Context Provider
When Engaging with This Project:
- Read First: Always review this file before making any changes to understand project constraints
- Follow Exactly: Adhere to the documented file structure and architectural decisions
- Maintain Consistency: Use established patterns and conventions without deviation
- No Alternatives: Never suggest alternative libraries or patterns unless explicitly requested
- Type Safety: Maintain TypeScript type safety in all generated code
## For AI Coding Assistants:
- System Prompt: Use this as your primary system prompt when working on this project
- Context Injection: Provide this file as context when asked to make changes
- Constraint Definition: Defines the boundaries and technical constraints for all work
- Architecture Guide: Documents the established patterns and conventions to follow
## When Generating Code:
- Review Structure: Understand where new code should fit in the documented architecture
- Follow Patterns: Use the established coding patterns and file organization
- Maintain Types: Ensure all generated code maintains TypeScript type safety
- Respect Boundaries: Work within the documented technical constraints
- This context provider ensures consistent, type-safe AI-assisted development across all work on this project.

## Project Overview
A production-ready Next.js full-stack application with authentication, database, tRPC, and AI integration. Inspired by T3 but designed to avoid dependency coupling issues.

## Core Technologies
- **Next.js App Router** with TypeScript
- **Shadcn** for UI development (Tailwind CSS)
- **Zod** for validation
- **tRPC** for type-safe APIs
- **NextAuth v4** with GitHub OAuth
- **Prisma** with Supabase PostgreSQL
- **OpenAI SDK** (provider-agnostic AI)

## Important Decisions
- Next.js App Router for modern routing
- TypeScript throughout for type safety
- Prisma + Supabase for database
- tRPC for type-safe APIs
- NextAuth v4 for authentication
- Provider-agnostic AI integration
- pnpm for package management

## Project Structure

### Root Configuration
```
├── .env.local         # Local environment variables
├── .env.example       # Template for environment variables
├── components.json    # Shadcn configuration
├── eslint.config.mjs  # ESLint configuration
├── next.config.ts     # Next.js configuration
├── package.json       # Dependencies and scripts
├── tsconfig.json      # TypeScript configuration
├── .prettierrc        # Prettier configuration
└── prisma/schema.prisma # Database schema
```

### Source Structure
```
src/
├── env.ts            # Zod environment validation
├── proxy.ts          # Route protection
├── app/              # Next.js app router
│   ├── layout.tsx    # Root layout
│   ├── page.tsx      # Homepage
│   └── api/          # API routes
│       ├── auth/[...nextauth]/route.ts
│       ├── trpc/[trpc]/route.ts
│       ├── health/route.ts
│       └── ai/
│           ├── chat/route.ts
│           ├── embeddings/route.ts
│           └── moderation/route.ts
├── components/       # React components
│   ├── providers.tsx # Provider wrappers
│   ├── ui/          # Shadcn components
│   ├── auth/        # Authentication components
│   ├── layout/      # Layout components
│   └── ai/          # AI feature components
├── lib/             # Utilities and types
│   ├── utils/       # Utility functions
│   ├── hooks/       # React hooks
│   └── types/       # TypeScript types
├── server/          # Server-side code
│   ├── auth/        # Authentication configuration
│   ├── ai/          # AI services
│   ├── trpc/        # tRPC setup
│   └── db.ts        # Database singleton
└── trpc/            # tRPC client setup
    ├── client/
    └── rpc/
```

### public resources and prisma configuration
```
├── public/         (public assets)
│   ├── favicon.ico (Site favicon)
│   ├── fonts/      (Self hosted font files)
│   └── images/     (Static image assets)
│
├── prisma/
│   ├── schema.prisma (Database schema definition)
│   └── seed.ts       (Database seeding script for local development)
```
## Key Implementation Details

### Environment Variables
- Always import from `@/env` from `src/env.ts` instead of `process.env`
- Use Zod validation for type safety
## Environment Configuration
```
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-secret-key
GITHUB_ID=your-github-client-id
GITHUB_SECRET=your-github-client-secret
DATABASE_URL=your-supabase-database-url
AI_BASE_URL=your-ai-base-url
AI_API_KEY=your-ai-api-key
AI_MODEL=gpt-4o-mini
AI_ORG_ID=your-ai-org-id (optional)
```

### Database
- Use Prisma with Supabase PostgreSQL adapter
- Singleton pattern in `src/server/db.ts`
- `prisma db push` for development, `prisma migrate dev` for production

### Authentication
- NextAuth v4 with GitHub OAuth
- Prisma adapter for session management
- Route protection via `src/proxy.ts`

### tRPC
- End-to-end type safety between client and server
- Context includes db, session, and user
- React client with `@trpc/react-query`

### AI Integration
- Provider-agnostic via `AI_BASE_URL`
- Services: chat, embeddings, moderation
- tRPC procedures for AI features

### UI Components
- Shadcn for rapid development
- Tailwind CSS for styling
- Responsive design patterns